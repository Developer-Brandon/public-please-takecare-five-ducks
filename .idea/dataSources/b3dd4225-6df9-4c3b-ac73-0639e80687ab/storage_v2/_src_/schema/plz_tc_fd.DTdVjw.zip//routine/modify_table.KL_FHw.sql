create
    definer = testUser@localhost procedure modify_table()
BEGIN

    IF NOT EXISTS((SELECT *
                   FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE table_name = 'tb_main_banner_img'
                     AND table_schema = 'plz_tc_fd'
                     AND column_name = 'use_yn')) THEN
        alter table plz_tc_fd.tb_main_banner_img add use_yn enum('y','n') not null default 'y' comment '사용여부' after file_name;
    END IF;

END;

