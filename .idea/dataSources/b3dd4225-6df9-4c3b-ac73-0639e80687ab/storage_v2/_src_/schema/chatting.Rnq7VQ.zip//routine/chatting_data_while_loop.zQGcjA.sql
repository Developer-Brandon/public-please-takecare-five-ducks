create
    definer = root@localhost procedure chatting_data_while_loop()
BEGIN
    DECLARE x INT;
    DECLARE allCount INT;
    DECLARE nowCount INT;

    SET x = 0;
    SET nowCount = 0;

    SET allCount = (SELECT COUNT(*) FROM chatting.TB_CHATTING_ROOM);

    WHILE x  <= allCount DO

            SET nowCount = (
                                    SELECT COUNT(*)
                                    FROM chatting.TB_CHATTING_MESSAGE
                                    GROUP BY ROOM_NO
                                    ORDER BY ROOM_NO
                                    LIMIT X, 1
                                );

            UPDATE chatting.TB_CHATTING_ROOM
               SET MSG_COUNT = nowCount
            WHERE ROOM_NO = (
                                SELECT *
                                FROM (SELECT ROOM_NO
                                      FROM chatting.TB_CHATTING_MESSAGE
                                      GROUP BY ROOM_NO
                                      ORDER BY ROOM_NO
                                      LIMIT X, 1) A
                            );
            SET  x = x + 1;
        END WHILE;

    SELECT allCount;
    END;

