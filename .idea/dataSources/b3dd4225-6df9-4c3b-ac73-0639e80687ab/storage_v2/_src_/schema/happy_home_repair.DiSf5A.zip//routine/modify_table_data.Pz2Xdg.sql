create
    definer = root@localhost procedure modify_table_data()
begin
    if((select explanation
                  from happy_home_repair.tb_repair_location
                  where name = 'SEOUL') = '') then
    update happy_home_repair.tb_repair_location
    set explanation = '서울'
    where name = 'SEOUL';
    end if;

    if((select explanation
                   from happy_home_repair.tb_repair_location
                   where name = 'INCHEON') = '') then
        update happy_home_repair.tb_repair_location
        set explanation = '인천'
        where name = 'INCHEON';
    end if;

    if((select explanation
                   from happy_home_repair.tb_repair_location
                   where name = 'KYEONG_KI_DO') = '') then
        update happy_home_repair.tb_repair_location
        set explanation = '경기도'
        where name = 'KYEONG_KI_DO';
    end if;
end;

