create
    definer = root@localhost procedure add_column_name_2()
BEGIN

    IF NOT EXISTS((SELECT *
                   FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE table_name = 'TB_THEME'
                     AND table_schema = 'market'
                     AND column_name = 'THEME_ICON_PATH')) THEN
        ALTER TABLE `TB_THEME` ADD `THEME_ICON_PATH` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '테마 아이콘 경로' AFTER THEME_EXP;

    END IF;

END;

