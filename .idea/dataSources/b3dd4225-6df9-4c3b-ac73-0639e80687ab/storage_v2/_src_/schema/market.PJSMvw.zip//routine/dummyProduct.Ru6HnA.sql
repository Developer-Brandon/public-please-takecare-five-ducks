create
    definer = root@localhost procedure dummyProduct()
begin
    declare i int default 1;

    while i <= 500 Do
            insert into TB_PD(USER_NO
                             ,RECOMMEND_PD_NO
                             ,AREA_NO
                             ,PLAY_STATE
                             ,OPEN_YN
                             ,MAX_ENTER_USER
                             ,PD_TITLE
                             ,PD_MESSAGE
                             ,PD_PRICE
                             ,PD_LINK
                             ,MOD_DT
                             ,REG_DT)
            SELECT USER_NO
                 ,RECOMMEND_PD_NO
                 ,AREA_NO
                 ,PLAY_STATE
                 ,OPEN_YN
                 ,MAX_ENTER_USER
                 ,CONCAT('(더미', i, ')', SUBSTRING(PD_TITLE, INSTR(PD_TITLE, ')') + 1, LENGTH(PD_TITLE)))
                 ,PD_MESSAGE
                 ,PD_PRICE
                 ,PD_LINK
                 ,MOD_DT
                 ,REG_DT FROM TB_PD

            LIMIT 10000;

            SET I = I + 1;
        end while;
END;

