create
    definer = root@localhost procedure add_column_name_3()
BEGIN

    IF NOT EXISTS((SELECT *
                   FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE table_name = 'TB_RECOMMENDED_PD'
                     AND table_schema = 'market'
                     AND column_name = 'R_PD_URL')) THEN
        ALTER TABLE market.TB_RECOMMENDED_PD
        ADD R_PD_URL TEXT NOT NULL COMMENT '상품 경로' AFTER R_PD_EXP;

        ALTER TABLE market.TB_RECOMMENDED_PD
        MODIFY USE_YN ENUM ('Y', 'N') DEFAULT 'Y' NOT NULL COMMENT '사용 여부' AFTER MOD_DT;
    END IF;

END;

