create
    definer = root@localhost procedure modify_table2()
BEGIN

    IF NOT EXISTS((SELECT *
                   FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE table_name = 'tb_inapp_main_banner'
                     AND table_schema = 'market'
                     AND column_name = 'MOD_DT')) THEN
        ALTER TABLE TB_INAPP_MAIN_BANNER ADD MOD_DT DATETIME DEFAULT CURRENT_TIMESTAMP() NOT NULL COMMENT '수정 일자' AFTER REG_DT;
    END IF;

END;

