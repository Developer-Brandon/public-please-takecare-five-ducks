create
    definer = root@localhost procedure modify_table3()
BEGIN

    IF NOT EXISTS((SELECT *
               FROM INFORMATION_SCHEMA.COLUMNS
               WHERE table_name = 'tb_inapp_main_banner'
                 AND table_schema = 'market'
                 AND column_name = 'HEX_CODE')) THEN
        ALTER TABLE TB_INAPP_MAIN_BANNER ADD HEX_CODE VARCHAR(20) NOT NULL DEFAULT '' COMMENT '색상 코드' AFTER ACCOUNT_NO;

        ALTER TABLE TB_INAPP_MAIN_BANNER MODIFY USE_YN ENUM('Y', 'N') NOT NULL DEFAULT 'N' COMMENT '사용 여부' AFTER MOD_DT;
    END IF;

END;

