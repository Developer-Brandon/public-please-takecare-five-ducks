create
    definer = root@localhost procedure add_column_name_1()
BEGIN

    IF NOT EXISTS((SELECT *
                   FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE table_name = 'TB_USER_REPORT_LIST'
                     AND table_schema = 'market'
                     AND column_name = 'FEED_NO')) THEN
        ALTER TABLE `TB_USER_REPORT_LIST` ADD `FEED_NO` INT UNSIGNED DEFAULT 0 NULL COMMENT '피드 번호' AFTER ROOM_NO;

    END IF;

END;

