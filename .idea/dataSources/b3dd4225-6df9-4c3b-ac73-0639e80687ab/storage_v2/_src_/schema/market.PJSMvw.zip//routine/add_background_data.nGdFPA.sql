create
    definer = root@localhost procedure add_background_data()
BEGIN

        IF NOT EXISTS((SELECT *
                   FROM market.TB_FEED_BACKGROUND_COLOR
                   WHERE HEX_CODE = '#d7f8da')) THEN

        # 1. 기존의 background color들 전부 update하여 사용안함 처리합니다.
        UPDATE market.TB_FEED_BACKGROUND_COLOR
        SET USE_YN = 'N';

        # 2. 지정한 배경색상 insert 해줍니다.
        INSERT INTO market.TB_FEED_BACKGROUND_COLOR(HEX_CODE)
        VALUES('#f1f1f1'),('#fff3d3'),('#d7f8da'),('#d1f3ff');

        END IF;

END;

